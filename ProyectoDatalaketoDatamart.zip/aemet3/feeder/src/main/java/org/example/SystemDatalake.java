package org.example;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;

import java.io.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;
import java.util.stream.Collectors;


public class SystemDatalake implements Datalake{

    private File createDatalake() {
        File directorio = new File("datalake");
        if (!directorio.exists()) {
            if (directorio.mkdirs()) {
                System.out.println("Directorio creado");

            } else {
                System.out.println("Error");
            }
        }
        return directorio;
    }

    private void writeData(List<Event> events, OutputStream outputStream) throws IOException {
        GsonBuilder builder = new GsonBuilder();
        Gson gson = builder.create();
        for (Event event : events) {
            String json = gson.toJson(event);
            outputStream.write(json.getBytes());
            outputStream.write("\n".getBytes());
        }
    }

    @Override
    public List<Event> read(Date date) throws IOException {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
        formatter.setTimeZone(TimeZone.getTimeZone("Atlantic/Canary"));
        String filename = formatter.format(date) + ".events";
        BufferedReader br = new BufferedReader(new FileReader("datalake/"+filename));
        StringBuilder sb = new StringBuilder();
        String line;

        List<Event> events = new ArrayList<>();
        while ((line=br.readLine()) != null){
            sb.append(line);
            JsonObject jsonObject = new Gson().fromJson(line, JsonObject.class);
            String instant = jsonObject.getAsJsonPrimitive("ts").getAsString();
            String stationName = jsonObject.getAsJsonPrimitive("stationName").getAsString();
            Double temp = jsonObject.getAsJsonPrimitive("ta").getAsDouble();
            String stationPlace = jsonObject.getAsJsonPrimitive("stationPlace").getAsString();
            Event event = new Event(instant, stationName, stationPlace, temp);
            events.add(event);
        }
        br.close();
        return events;
    }

    SimpleDateFormat DateFor = new SimpleDateFormat("dd/MM/yyyy");
    @Override
    public void store(Date date, List<Event> events) throws IOException, ParseException {

        File directory = createDatalake();

        // Cogemos las fechas de los eventos
        List<Date> dates = new ArrayList<>();
        for(Event event:events) {
            String instant = event.getTs();
            String year = instant.substring(0, 4);
            String month = instant.substring(5, 7);
            String day = instant.substring(8, 10);
            Date dateEvent = DateFor.parse(day + "/" + month + "/" + year);
            dates.add(dateEvent);
        }

        // Quitamos las fechas repetidas
        List<Date> datesNR = dates.stream().distinct().collect(Collectors.toList());
        // Escribimos las fechas en el archivo de fechas


        // Filtramos los eventos que sean del dia anterior y los de hoy
        List<Event> eventsY = isYesterdayEvents(events);
        List<Event> eventsN = isTodayEvents(events);

        // Creamos los ficheros con su fecha correspondiente, los escribimos, y cerramos conexion
        if(datesNR.size()==2){
            OutputStream outputStreamYesterday = createFile(datesNR.get(0), directory);
            OutputStream outputStreamToday = createFile(datesNR.get(1), directory);

            writeData(eventsY, outputStreamYesterday);
            outputStreamYesterday.close();

            writeData(eventsN, outputStreamToday);
            outputStreamToday.close();
        } else{
            OutputStream outputStreamToday = createFile(datesNR.get(0), directory);
            writeData(eventsN, outputStreamToday);
            outputStreamToday.close();
        }

    }

    private List<Event> isTodayEvents(List<Event> events) throws ParseException {
        LocalDate today = LocalDate.now();

        List<Event> eventsN = new ArrayList<>();
        for (Event event:events){
            LocalDate dateEvent = LocalDate.parse(event.getTs().substring(0, 10));
            if (dateEvent.isEqual(today)){
                eventsN.add(event);
            }
        }
        return eventsN;
    }

    private List<Event> isYesterdayEvents(List<Event> events) throws ParseException {
        List<Event> eventsY = new ArrayList<>();
        LocalDate today = LocalDate.now();

        for (Event event:events){
            LocalDate dateEvent = LocalDate.parse(event.getTs().substring(0, 10));
            if (!dateEvent.isEqual(today)){
                eventsY.add(event);
            }

        }
        return eventsY;
    }

    private OutputStream createFile(Date date, File directory) throws IOException {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
        formatter.setTimeZone(TimeZone.getTimeZone("Atlantic/Canary"));
        String filename = formatter.format(date) + ".events";
        File file = new File(directory, filename);
        if (!file.exists()) {
            // crea el archivo para el día actual
            file.createNewFile();
        }
        // devuelve un OutputStream para escribir en el archivo
        return new FileOutputStream(file, true);
    }

}
