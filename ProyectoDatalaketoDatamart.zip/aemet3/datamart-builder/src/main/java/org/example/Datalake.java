package org.example;

import java.io.File;
import java.io.IOException;
import java.util.List;

public interface Datalake {
    List<List<Weather>> read(File directory) throws IOException;
    Weather selectMax(List<Weather> events);
    Weather selectMin(List<Weather> events);
}
