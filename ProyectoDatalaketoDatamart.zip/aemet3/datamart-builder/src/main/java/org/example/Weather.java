package org.example;

public class Weather {
    private final String Date;
    private final String stationName;
    private final Double value;
    private final String time;
    private final String stationPlace;


    public Weather(String ts, String stationName, Double ta, String stationPlace, String time) {
        this.Date = ts;
        this.stationName = stationName;
        this.value = ta;
        this.stationPlace = stationPlace;
        this.time=time;
    }

    public String getTime() {return time;}
    public String getDate() {
        return Date;
    }
    public String getStationName() {return stationName;}
    public Double getValue() {return value;}
    public String getStationPlace() {return stationPlace;}
}
