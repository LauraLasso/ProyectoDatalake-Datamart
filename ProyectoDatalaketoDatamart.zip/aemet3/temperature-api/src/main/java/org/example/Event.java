package org.example;

public class Event {
    private String date;
    private String time;
    private String stationName;
    private String stationPlace;
    private double temp;

    public Event(String date, String time, String stationName, String stationPlace, double temp) {
        this.date = date;
        this.time = time;
        this.stationName = stationName;
        this.stationPlace = stationPlace;
        this.temp = temp;
    }

    public String getDate() {return date;}
    public String getTime() {return time;}
    public String getStationName() {return stationName;}
    public String getStationPlace() {return stationPlace;}
    public double getTemp() {return temp;}
}
