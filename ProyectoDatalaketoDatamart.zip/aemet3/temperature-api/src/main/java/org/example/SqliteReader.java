package org.example;

import java.sql.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class SqliteReader implements DatabaseReader{
    public final Connection connection;

    public SqliteReader() throws SQLException {
        String url = "jdbc:sqlite:datamart.db";
        connection = DriverManager.getConnection(url);
    }

    @Override
    public List<Event> read(LocalDate from, LocalDate to, String sql) throws SQLException {
        List<Event> allEvents = new ArrayList<>();
        ResultSet resultSet = connection.prepareStatement(sql).executeQuery();

        // Cogemos los valores de cada columna correspondiente a cada fila
        while (resultSet.next()){
            String time = resultSet.getString("time");
            String date = resultSet.getString("date");
            String station = resultSet.getString("station");
            String place = resultSet.getString("place");
            Double temp = resultSet.getDouble("value");
            allEvents.add(new Event(date, time, station, place, temp));
        }

        List<Event> eventsEqualDate = allEvents.stream()
                .filter(event -> isEqual(eventDate(event.getDate()), from, to))
                .collect(Collectors.toList());

        List<Event> eventsIn = allEvents.stream()
                .filter(event -> eventDate(event.getDate()).isAfter(from) && eventDate(event.getDate()).isBefore(to))
                .collect(Collectors.toList());

        List<Event> filterEvents = Stream.concat(eventsEqualDate.stream(), eventsIn.stream()).distinct().collect(Collectors.toList());

        return filterEvents;
    }

    private boolean isEqual(LocalDate eventDate, LocalDate from, LocalDate to) {
        if(eventDate.isEqual(from)){
            return true;
        }
        if(eventDate.isEqual(to)) {
            return true;
        }
        return false;
    }

    private LocalDate eventDate(String date) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        return LocalDate.parse(date, formatter);
    }
}