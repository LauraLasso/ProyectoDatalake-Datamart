package org.example;

import java.util.List;

public interface Loader {
    List<Event> load();
}
