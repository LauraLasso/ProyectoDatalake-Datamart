package org.example;

public class Event {

    private final String ts;
    private final String stationName;
    private final Double ta;
    private final String stationPlace;

    public Event(String ts,  String station, String stationPlace, Double ta) {
        this.ts = ts;
        this.stationName = station;
        this.stationPlace = stationPlace;
        this.ta = ta;
    }

    public String getTs() {
        return ts;
    }
    public String getStationName() {return stationName;}
    public Double getTa() {return ta;}
    public String getStationPlace() {return stationPlace;}
}
