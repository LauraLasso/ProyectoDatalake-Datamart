package org.example;

public class Controller {
    public APISource api;
    public Controller(APISource api) {
        this.api = api;
    }
    public void start(){
        api.startServer();
        api.start();
    }
}
