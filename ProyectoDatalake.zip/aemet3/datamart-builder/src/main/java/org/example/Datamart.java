package org.example;

import java.sql.SQLException;
import java.util.Date;
import java.util.List;

public interface Datamart {
    void initDatabase() throws SQLException;
    void addMax(Weather weather) throws SQLException;
    void addMin(Weather weather) throws SQLException;
    List<Weather> read(String sql) throws SQLException;
    void deleteTable(String sql) throws SQLException;
}
