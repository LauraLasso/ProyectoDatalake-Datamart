package org.example;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class DatabaseWriter implements Datamart{
    private final Connection connection;

    public DatabaseWriter() throws SQLException {
        String url ="jdbc:sqlite:datamart.db";
        connection = DriverManager.getConnection(url);
        initDatabase();
    }

    private static final String TEMPMAX =
            "CREATE TABLE IF NOT EXISTS tempMax (" +
                    "date TEXT, " +
                    "time TEXT, " +
                    "place TEXT, " +
                    "station TEXT, " +
                    "value NUMBER);";
    private static final String TEMPMIN =
            "CREATE TABLE IF NOT EXISTS tempMin (" +
                    "date TEXT, " +
                    "time TEXT, " +
                    "place TEXT, " +
                    "station TEXT, " +
                    "value NUMBER);";

    public void initDatabase() throws SQLException {
        connection.createStatement().execute(TEMPMAX);
        connection.createStatement().execute(TEMPMIN);
    }

    @Override
    public void addMax(Weather weather) throws SQLException {
        try{
            connection.createStatement().execute(SqliteWriter.insertTempMaxStatementOf(weather));
        }
        catch (SQLException e){
            e.printStackTrace();
        }
    }

    @Override
    public void addMin(Weather weather) throws SQLException {
        try{
            connection.createStatement().execute(SqliteWriter.insertTempMinStatementOf(weather));
        }
        catch (SQLException e){
            e.printStackTrace();
        }
    }

    @Override
    public List<Weather> read(String sql) throws SQLException {
        List<Weather> allEvents = new ArrayList<>();
        ResultSet resultSet = connection.prepareStatement(sql).executeQuery();

        // Cogemos los valores de cada columna correspondiente a cada fila
        while (resultSet.next()){
            String time = resultSet.getString("time");
            String dateEvent = resultSet.getString("date");
            String station = resultSet.getString("station");
            String place = resultSet.getString("place");
            Double temp = resultSet.getDouble("value");
            allEvents.add(new Weather(dateEvent, station, temp, place, time));
        }
        return allEvents;
    }

    @Override
    public void deleteTable(String sql) throws SQLException {
        connection.createStatement().execute(sql);
    }


}
