package org.example;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

import java.io.*;
import java.util.*;

public class FileDatalake implements Datalake{
    @Override
    public List<List<Weather>> read(File directory) throws IOException, NullPointerException {
        // Recorremos los archivos que se encuentran en el datalake
        List<List<Weather>> allEvents = new ArrayList<>();

        for (File file: Objects.requireNonNull(directory.listFiles())){
            List<Weather> events = new ArrayList<>();
            BufferedReader br = new BufferedReader(new FileReader(file));

            String line;
            while ((line= br.readLine())!=null){
                JsonObject jsonObject = new Gson().fromJson(line, JsonObject.class);
                String instant = jsonObject.getAsJsonPrimitive("ts").getAsString();

                // Cogemos la fecha y la hora del instant
                String date = instant.substring(0, 10);
                String time = instant.substring(11, 19);
                String stationName = jsonObject.getAsJsonPrimitive("stationName").getAsString();
                String stationPlace = jsonObject.getAsJsonPrimitive("stationPlace").getAsString();
                Double temp = jsonObject.getAsJsonPrimitive("ta").getAsDouble();

                Weather event = new Weather(date, stationName, temp, stationPlace, time);
                events.add(event);
            }
            allEvents.add(events);
        }
        return allEvents;
    }

    @Override
    public Weather selectMax(List<Weather> events) {
        Optional<Weather> maxEvent= events.stream().max(Comparator.comparing(e->e.getValue()));
        if (maxEvent.isPresent()){
            return maxEvent.get();
        }
        else {
            System.out.println("No hay un evento con temperatura máxima en el día: "+events.get(0).getDate());
            return null;
        }
    }

    @Override
    public Weather selectMin(List<Weather> events) {
        Optional<Weather> minEvent = events.stream().min(Comparator.comparing(e->e.getValue()));
        if(minEvent.isPresent()){
            return minEvent.get();
        }
        else {
            System.out.println("No hay un evento con temperatura mínima en el día: "+events.get(0).getDate());
            return null;
        }
    }
}
