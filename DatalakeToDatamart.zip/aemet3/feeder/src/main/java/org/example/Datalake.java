package org.example;

import java.io.IOException;
import java.text.ParseException;
import java.util.Date;
import java.util.List;

public interface Datalake {
    List<Event> read(Date date) throws IOException;
    void store(Date date, List<Event> events) throws IOException, ParseException;
}
