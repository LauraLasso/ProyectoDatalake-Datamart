package org.example;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.ParseException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static java.util.Calendar.HOUR;


public class Controller {
    // Inicializamos las interfaces
    private final Loader loader;
    private final Datalake datalake;

    private final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    private final DateTimeFormatter formatterTime = DateTimeFormatter.ofPattern("HH:mm:ss");

    public Controller(Loader loader, Datalake datalake) {
        this.loader = loader;
        this.datalake = datalake;
    }

    public void start() throws IOException, ParseException {
        schedule(task());
    }

    private TimerTask task() throws IOException, ParseException {
        List<Event> NowEvents = loader.load();
        try{
            List<Event> events = filterEvents(new Date(), NowEvents);
            // Añadimos esa lista en el datalake
            if(!events.isEmpty()){
                datalake.store(new Date(), events);
            }

        }catch (FileNotFoundException e){
            try {
                Calendar calendar= Calendar.getInstance();
                calendar.add(Calendar.DATE, -1);
                Date yesterday = calendar.getTime();
                List<Event> yesterdayEvents = filterEvents(yesterday, NowEvents);
                List<Event> todayEvents = NowEvents.stream()
                        .filter(event -> dateEvent(event.getTs()).isEqual(LocalDate.now()))
                        .collect(Collectors.toList());
                List<Event> allEvents = Stream.concat(yesterdayEvents.stream(), todayEvents.stream())
                        .collect(Collectors.toList());
                datalake.store(new Date(), allEvents);
            } catch (FileNotFoundException a){
                datalake.store(new Date(), NowEvents);
            }
        }
        return null;
    }
    public List<Event> filterEvents(Date date, List<Event> events) throws IOException {
        List<Event> lastEvents = datalake.read(date);
        Event lastEvent = lastEvents.get(lastEvents.size()-1);
        String instant = lastEvent.getTs();
        LocalDate lastDate = LocalDate.parse(instant.substring(0, 10), formatter);
        LocalTime lastTime = LocalTime.parse(instant.substring(11, 19), formatterTime);

        // Filtramos los eventos cogidos por la fecha y hora de ese evento
        List<Event> newEvents = events.stream()
                .filter(event -> dateEvent(event.getTs()).isEqual(lastDate))
                .filter(event -> timeEvent(event.getTs()).isAfter(lastTime))
                .collect(Collectors.toList());
        return newEvents;
    }

    private LocalTime timeEvent(String ts) {
        return LocalTime.parse(ts.substring(11, 19), formatterTime);
    }
    private LocalDate dateEvent(String ts) {
        return LocalDate.parse(ts.substring(0, 10), formatter);
    }
    private void schedule(TimerTask task) {
        new Timer().schedule(task, 0, HOUR); // O HOUR
    }

}
