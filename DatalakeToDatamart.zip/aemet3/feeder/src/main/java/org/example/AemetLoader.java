package org.example;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import org.jsoup.Connection;
import org.jsoup.Jsoup;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

import static java.util.Collections.emptyList;

public class AemetLoader implements Loader{
    public static final String aemeturl = "https://opendata.aemet.es/opendata/api/observacion/convencional/todas";
    private static final String apiKey = "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJsYXVyYS5sYXNzb2dhckBnbWFpbC5jb"+
            "20iLCJqdGkiOiI3M2JhNjYwNy1mYTljLTQ2OWYtODQ3ZC1mYmFlNmNhZmJhZmMiLCJpc3MiOiJBRU1FVCIsIml"+
            "hdCI6MTY3MTE4NDI2NiwidXNlcklkIjoiNzNiYTY2MDctZmE5Yy00NjlmLTg0N2QtZmJhZTZjYWZiYWZjIiwicm"+
            "9sZSI6IiJ9.1v2R0KeHayTXREUuA90VYYCbBCdQvsbnJ6fM5NVW4Ac";

    @Override
    public List<Event> load() {
        try{
            String json = get(aemeturl);
            String url = urlIn(json);
            return parse(get(url));
        } catch(Exception e){
            System.out.println("ERROR EN HACER EL PARSE(GET(URLIN(GET()))))): " + e.getMessage());
            return emptyList();
        }
    }

    private String urlIn(String json) {

        return new Gson().fromJson(json, JsonObject.class).
                get("datos").
                getAsString();
    }

    public static String get(String url) throws IOException {
        String response = Jsoup.connect(url)
                .timeout(6000)
                .ignoreContentType(true)
                .header("accept", "application/json")
                .header("api_key", apiKey)
                .method(Connection.Method.GET)
                .maxBodySize(0).execute().body();
        return response;
    }


    private List<Event> parse(String json)  {
        JsonArray jsonArray= new Gson().fromJson(json, JsonArray.class);
        return parse(jsonArray.asList());
    }

    private List<Event> parse(List<JsonElement> list) {
        List<Event> collect = list.stream()
                .map(JsonElement::getAsJsonObject)
                .filter(o -> o.getAsJsonPrimitive("lon").getAsDouble() < -15)
                .filter(o -> o.getAsJsonPrimitive("lon").getAsDouble() > -16)
                .filter(o -> o.getAsJsonPrimitive("lat").getAsDouble() > 27.5)
                .filter(o -> o.getAsJsonPrimitive("lat").getAsDouble() < 28.4)//Si esta en gran canaria
                .filter(o->o.has("ta")==true)
                .map(o1 -> {
                    try {
                        return eventIn(o1);
                    } catch (ParseException e) {
                        throw new RuntimeException(e);
                    }
                })
                .collect(Collectors.toList());
        return collect;
    }

    private Event eventIn(JsonObject o) throws ParseException {
        String instant = o.getAsJsonPrimitive("fint").getAsString();
        String station = o.getAsJsonPrimitive("ubi").getAsString();
        Double temp = o.getAsJsonPrimitive("ta").getAsDouble();
        String stationPlace = o.getAsJsonPrimitive("idema").getAsString();

        return new Event(instant, station, stationPlace, temp);
    }
}
