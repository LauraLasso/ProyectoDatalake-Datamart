package org.example;

import spark.Request;
import spark.Response;

import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import static spark.Spark.*;

//http://localhost:4567/
//http://localhost:4567/v1/places/with-max-temerature
public class SparkWebService implements APISource{
    private final Command eventsManager;
    private final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    public APISource startServer() {
        port(4567);
        staticFiles.location("/public");
        return null;
    }

    public SparkWebService() throws SQLException {
        this.eventsManager = new EventsManager();
    }

    public void start() {
        get("v1/places/with-max-temerature", this::max);
        get("v1/places/with-min-temerature", this::min);
    }

    private String min(Request request, Response response) throws SQLException {
        response.type("application/json");
        LocalDate from = LocalDate.parse(request.queryParams("from"), formatter);
        LocalDate to = LocalDate.parse(request.queryParams("to"), formatter);
        List<Event> events = eventsManager.getMinTemperatures(from, to);
        return eventsManager.toJson(events);
    }

    private String max(Request request, Response response) throws SQLException, NullPointerException {
        response.type("application/json");
        LocalDate from = LocalDate.parse(request.queryParams("from"), formatter);
        LocalDate to = LocalDate.parse(request.queryParams("to"), formatter);
        List<Event> events = eventsManager.getMaxTemperatures(from, to);
        System.out.println(events);
        return eventsManager.toJson(events);
    }

}