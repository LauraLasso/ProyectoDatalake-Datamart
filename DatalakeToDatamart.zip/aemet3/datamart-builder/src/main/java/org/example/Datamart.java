package org.example;

import java.sql.SQLException;
import java.util.List;

public interface Datamart {
    void addMax(Weather weather) throws SQLException;
    void addMin(Weather weather) throws SQLException;
}
