package org.example;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;

public class DatabaseWriter implements Datamart{
    private final Connection connection;

    public DatabaseWriter() throws SQLException {
        String url ="jdbc:sqlite:datamart.db";
        connection = DriverManager.getConnection(url);
        initDatabase();
    }

    private static final String TEMPMAX =
            "CREATE TABLE IF NOT EXISTS tempMax (" +
                    "date TEXT, " +
                    "time TEXT, " +
                    "place TEXT, " +
                    "station TEXT, " +
                    "value NUMBER);";
    private static final String TEMPMIN =
            "CREATE TABLE IF NOT EXISTS tempMin (" +
                    "date TEXT, " +
                    "time TEXT, " +
                    "place TEXT, " +
                    "station TEXT, " +
                    "value NUMBER);";

    private void initDatabase() throws SQLException {
        connection.createStatement().execute(TEMPMAX);
        connection.createStatement().execute(TEMPMIN);
    }

    @Override
    public void addMax(Weather weather) throws SQLException {
        try{
            connection.createStatement().execute(SqliteWriter.insertTempMaxStatementOf(weather));
        }
        catch (SQLException e){
            e.printStackTrace();
        }
    }

    @Override
    public void addMin(Weather weather) throws SQLException {
        try{
            connection.createStatement().execute(SqliteWriter.insertTempMinStatementOf(weather));
        }
        catch (SQLException e){
            e.printStackTrace();
        }
    }

}
