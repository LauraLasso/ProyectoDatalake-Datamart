package org.example;

public class SqliteWriter{
    private static final String INSERT_TEMPMAX =
            "INSERT INTO tempMax(date, time, place, station, value) VALUES ('%s', '%s', '%s', '%s', '%f')";
    private static final String INSERT_TEMPMIN =
            "INSERT INTO tempMin(date, time, place, station, value) VALUES ('%s', '%s', '%s', '%s', '%f')";
    public static String insertTempMaxStatementOf(Weather weather){
        return String.format(INSERT_TEMPMAX,
                weather.getDate(),
                weather.getTime(),
                weather.getStationPlace(),
                weather.getStationName(),
                weather.getValue());
    }
    public static String insertTempMinStatementOf(Weather weather){
        return String.format(INSERT_TEMPMIN,
                weather.getDate(),
                weather.getTime(),
                weather.getStationPlace(),
                weather.getStationName(),
                weather.getValue());
    }
}
