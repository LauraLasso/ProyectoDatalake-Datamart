package org.example;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import static java.util.Calendar.HOUR;
import static jdk.nashorn.internal.parser.DateParser.DAY;

public class Controller {
    private final Datalake datalake;
    private final Datamart datamart;

    public Controller(Datalake datalake, Datamart datamart) {
        this.datalake = datalake;
        this.datamart = datamart;
    }

    public void start() throws SQLException, IOException {
        schedule(task());
    }

    private TimerTask task() throws SQLException, IOException {
        // Creamos la base de datos
        //Datamart datamart1 = new DatabaseWriter();
        File directory = new File("datalake");
        // Filtramos esos eventos por fecha
        List<List<Weather>> events = datalake.read(directory); // Este método devolverá una lista de listas, que corresponderán con los archivos
        System.out.println(events.size());

        // Luego elegimos los que tengan temperatura máxima y mínima y los añadimos a las tablas de las bases de datos
        for(List<Weather> weather:events){
            Weather maxEvent = datalake.selectMax(weather);
            System.out.println(maxEvent);
            if(maxEvent!=null){
                datamart.addMax(maxEvent);
            }
            Weather minEvent = datalake.selectMin(weather);
            if (minEvent!=null){
                datamart.addMin(minEvent);
            }
            System.out.println(minEvent);
        }
        return null;
    }
    private void schedule(TimerTask task) {
        new Timer().schedule(task, 0, DAY); // O HOUR
    }

}
